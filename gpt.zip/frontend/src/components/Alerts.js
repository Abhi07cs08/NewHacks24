import React from 'react';

function Alerts() {
    return (
        <div>
            <h3>Alerts Component</h3>
            <p>This will display disaster alerts.</p>
        </div>
    );
}

export default Alerts; 
