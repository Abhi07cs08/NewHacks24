import React from 'react';

function ShelterFinder() {
    return (
        <div>
            <h3>Shelter Finder Component</h3>
            <p>This will help find nearby shelters.</p>
        </div>
    );
}

export default ShelterFinder;
